struct Point
{
	int x;
	int y;
};

int main()
{
	Point pt;

	// ��Ģ 1. 
	Point& r1 = pt;
	Point& r2 = Point();


}