// F43 ~ F44 ( 22 page)

int x = 10;

int f1() { return x; }

int main()
{
	int ret = f1();

	f1() = 20; // ?
}