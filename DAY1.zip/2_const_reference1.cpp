// F16 ~ F20  ( 10 page ~)

#include <iostream>

struct Rect
{
	int left, top, right, bottom;
};

void fn(Rect rc)
{
}
int main()
{
	Rect rc;
	fn(rc);
}
const_reference