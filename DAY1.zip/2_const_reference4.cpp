#include <iostream>
#include <string>

int main()
{
	std::string s1 = "abcdefghijklmnopqrstu";
	std::string s2 = "abcdefghijklmnopqrstu";

	std::string s3 = s1;
	std::string s4 = std::move(s1);

	std::cout << s3 << std::endl;
	std::cout << s4 << std::endl;
}