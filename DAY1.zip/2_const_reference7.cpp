#include <iostream>
#include <string>

class People
{
	std::string name;
	std::string addr;
public:
	People(const std::string& name, const std::string& addr) : name(name), addr(addr)
	{
	}
};

int main()
{
	std::string s1 = "john";
	std::string s2 = "seoul";

	People p(s1, s2);
}