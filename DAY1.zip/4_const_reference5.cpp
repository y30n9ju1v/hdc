#include <iostream>
#include <string>

class People
{
	std::string name;
public:
	void setName(const std::string& s)
	{
		name = s;
	}
};

int main()
{
	std::string s = "john";

	People p;
	p.setName(s);
}