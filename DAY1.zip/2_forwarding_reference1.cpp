// F.19: For ��forward�� parameters, pass by TP&& and only std::forward the parameter

template<typename T> void foo(T a)
{
	T& r = a;
}


int main()
{
	int n = 10;

	int&  r1 = ? ;
	int&& r2 = ? ;

	int&& r3 = ? ;

	using LREF = int&; // typedef int& LREF;
	using RREF = int&&;

	LREF r4 = ? ;
	RREF r5 = ?;

	// reference collapsing
	LREF& r6 = ? ;
	RREF& r7 = ? ;
	LREF&& r8 = ? ;
	RREF&& r9 = ?;
}





