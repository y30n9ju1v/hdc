#include <iostream>

struct Rect
{
	int left, top, right, bottom;
};

void f1(Rect& rc)       {}
void f2(const Rect& rc) {}

int main()
{
	Rect rc;
	fn(rc);
}