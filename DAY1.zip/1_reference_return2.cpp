#include <iostream>

class Counter
{
	int value{ 0 };
public:
	Counter increment()
	{
		++value;
		return *this;
	}
	int get() const { return value; }

};

int main()
{
	Counter c;
	c.increment().increment().increment();

	std::cout << c.get() << std::endl;
}