// T.141: Use an unnamed lambda if you need a simple function object in one place only

#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

int main()
{
	auto f1 = [](int a, int b) {return a + b; };

	std::vector<int> v = { 1,3,5,2,4,6 };

	std::sort(v.begin(), v.end(), [](int a, int b) { return a < b; });

}