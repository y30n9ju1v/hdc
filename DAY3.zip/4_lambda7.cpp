// conversion function pointer

int main()
{
	auto f = [](int a, int b) { return a + b; };
}