﻿// F50 ~ F54 - 람다 표현식 사용한 관한 코딩 관례
// F.50 : Use a lambda when a function won't do (to capture local variables, or to write a local function)
// F.52 : Prefer capturing by reference in lambdas that will be used locally, including passed to algorithms
// F.53 : Avoid capturing by reference in lambdas that will be used non - locally, including returned, stored on the heap, or passed to another thread
// F.54 : If you capture this, capture all variables explicitly(no default capture)

#include <iostream>


struct plus
{
	int operator()(int a, int b) 
	{
		return a + b;
	}
};

int main()
{
	plus p;
	int n = p(1, 2);
}