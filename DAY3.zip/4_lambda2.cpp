#include <iostream>
#include <algorithm>
#include <vector>

// F.50 : Use a lambda when a function won't do (to capture local variables, or to write a local function)

int main()
{
	std::vector<int> v = { 4,5,6,1,2,3,7,8,9,0 };

	auto ret1 = std::find(v.begin(), v.end(), 3);
}