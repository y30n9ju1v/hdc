﻿// R.22 : Use make_shared() to make shared_ptrs
// R.23 : Use make_unique() to make unique_ptrs

#include <iostream>
#include <memory>

struct Point
{
	int x;
	int y;
	
	Point(int a, int b) : x(a), y(b) {}
};

int main()
{
	std::shared_ptr<Point> sp1 = new Point(1, 2);
	
	std::shared_ptr<Point> sp2(new Point(1, 2));

	std::shared_ptr<Point> sp3 = std::make_shared<Point>(1, 2);
}