﻿// R.22 : Use make_shared() to make shared_ptrs
// R.23 : Use make_unique() to make unique_ptrs

#include <iostream>
#include <memory>

void* operator new(std::size_t sz)
{
	std::cout << "new : " << sz << std::endl;
	return malloc(sz);
}

struct Point
{
	int x;
	int y;

	Point(int a, int b) : x(a), y(b) {}
};

int main()
{
	std::shared_ptr<Point> sp1(new Point(1, 2));

//	std::shared_ptr<Point> sp2 = std::make_shared<Point>(1, 2);
}


void foo(std::shared_ptr<Point> sp, int n) {}

int goo() { return 10; }