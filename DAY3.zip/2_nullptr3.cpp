#include <iostream>
#include <vector>

class Object
{
public:
	Object(int n, int* p) {}
};

int main()
{
	std::vector<Object> v;

	Object obj(0, 0);
	v.push_back(obj);

}




