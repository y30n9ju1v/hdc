﻿// SL.str.2: Use std::string_view or gsl::span<char> to refer to character sequences

#include <iostream>
#include <string>
#include <string_view>

void f(std::string s)
{
	
}

int main()
{
	std::string s = "sfjsdjflsdjflsjlfks";

	f(s);
}