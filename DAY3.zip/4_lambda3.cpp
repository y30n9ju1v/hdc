#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

bool cmp(int a, int b) { return a < b; }

int main()
{
	std::vector<int> v = { 1,3,5,2,4,6 };

	std::sort(v.begin(), v.end(), cmp);



}