#include <iostream>

template<typename F, typename ... T>
decltype(auto) chronometry(F f, T&& ... arg)
{
	return f(std::forward<T>(arg)...);
}


void foo(int* p) {}

int main()
{
	foo(0);

	chronometry(foo, 0);
}
