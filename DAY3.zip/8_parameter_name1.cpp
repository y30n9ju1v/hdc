﻿// E.25: If you can't throw exceptions, simulate RAII for resource management
// CP.20: Use RAII, never plain lock() / unlock()
// F.9: Unused parameters should be unnamed

#include <iostream>
#include <mutex>

template<typename T> class lock_guard
{
	T& mtx;
public:
	lock_guard(T& m) : mtx(m) { mtx.lock(); }
	~lock_guard() { mtx.unlock(); }
};


std::mutex m;
int shared_data = 0;

void foo()
{
	m.lock();
	shared_data = 100;

	// 예외 발생..
	m.unlock();
}


int main()
{

}