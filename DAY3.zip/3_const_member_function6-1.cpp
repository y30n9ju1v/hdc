#include <iostream>
#include <vector>
#include <algorithm>

template<typename T>
class take_view 
{
	T& r;
	int count;
public:
	take_view(T& r, int c) : r(r), count(c) {}

	auto begin() { return r.begin(); }
	auto end()   { return r.begin() + count; }
};


int main()
{
	std::vector<int> v = { 1,2,3,7,8,9,4,5,6,10 };
	
	for (auto n : v)
		std::cout << n << ", ";


}