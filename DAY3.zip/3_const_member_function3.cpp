#include <iostream>

class Point
{
public:
	int x, y;

	Point(int a, int b) : x(a), y(b) {}

	void set(int a, int b) { x = a; y = b; }

	// �ٽ� : ��� ��� �Լ��� Ư¡

	void print() 
	{
		x = 10;
		set(10, 20);

		int* p = reinterpret_cast<int*>(this);

		std::cout << x << ", " << y << std::endl;
	}
};

int main()
{
	Point pt(1, 2);
	pt.print();

	const Point cp(1, 2);
	cp.print();
}


