#include <iostream>

template<typename T> class vector
{
	T* buff;
	int size;
public:
	vector(int sz) : buff(new T[sz]), size(sz) {}

	~vector() { delete[] buff; }
};
int main()
{
	vector<int> v(10);
	v[0] = 0; 
	int a = v[0];
}