#include <iostream>
#include <string>

class People
{
	std::string name;
	std::string addr;
public:
	People(const std::string& name, const std::string& addr) : name(name), addr(addr)
	{
		std::cout << "ctor 1" << std::endl;
	}
	People(std::string&& name, const std::string& addr) : name(std::move(name)), addr(addr)
	{
		std::cout << "ctor 2" << std::endl;
	}
	People(const std::string& name, std::string&& addr) : name(name), addr(std::move(addr))
	{
		std::cout << "ctor 3" << std::endl;
	}
	People(std::string&& name, std::string&& addr) : name(std::move(name)), addr(std::move(addr))
	{
		std::cout << "ctor 4" << std::endl;
	}
};

int main()
{
	std::string s1 = "john";
	std::string s2 = "seoul";

	People p1(s1, s2); 
	People p2(std::move(s1), s2); 
	People p3(s1, std::move(s2)); 
								  
	People p4(std::move(s1), std::move(s2));

}